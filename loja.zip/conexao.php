<?php

	$conexao = mysqli_connect('mysql.hostinger.com.br','u550906188_loja','123456','u550906188_loja');
	//$conexao = mysqli_connect('localhost','root','','loja');
