					</div>
				</div>
			</div>	
		</main>
		<footer>
		</footer>
		<!--<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>-->
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
	</body>
</html>